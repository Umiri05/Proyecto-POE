using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Sistema Reina FIEC")]
[assembly: AssemblyDescription("Sistema de Gestión de Elecciones")]
[assembly: AssemblyCompany("FIEC")]
[assembly: AssemblyProduct("ReinaFIEC")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: ComVisible(false)]
[assembly: Guid("8b9c5d76-1234-4567-89ab-cdef01234567")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
